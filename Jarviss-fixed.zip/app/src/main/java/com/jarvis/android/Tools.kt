package com.jarvis.android

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.view.KeyEvent
import android.media.AudioManager
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

object Tools {

    /** Gemini'ye bildirilen araçlar (V3'teki tool_defs.py'nin Android karşılığı). */
    const val declarationsJson = """
    [
     {"name":"open_app","description":"Telefondaki bir uygulamayı adıyla açar.",
      "parameters":{"type":"OBJECT","properties":{"app_name":{"type":"STRING"}},"required":["app_name"]}},
     {"name":"sys_info","description":"Cihaz bilgisi: battery (pil), time (saat/tarih).",
      "parameters":{"type":"OBJECT","properties":{"kind":{"type":"STRING","description":"battery veya time"}},"required":["kind"]}},
     {"name":"get_weather","description":"Hava durumu özeti. Konum verilmezse IP'den bulunur.",
      "parameters":{"type":"OBJECT","properties":{"location":{"type":"STRING"}}}},
     {"name":"browser_control","description":"Web'de arama yapar, URL açar veya YouTube'da arar.",
      "parameters":{"type":"OBJECT","properties":{
        "action":{"type":"STRING","description":"search, open_url veya play_youtube"},
        "query":{"type":"STRING"},"url":{"type":"STRING"}},"required":["action"]}},
     {"name":"play_media","description":"YouTube veya Spotify'da müzik/video arar ve açar.",
      "parameters":{"type":"OBJECT","properties":{
        "query":{"type":"STRING"},"provider":{"type":"STRING","description":"youtube, spotify veya auto"}},"required":["query"]}},
     {"name":"control_media","description":"Çalan medyayı kontrol eder: pause, resume, next, previous, stop.",
      "parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING"}},"required":["action"]}},
     {"name":"add_calendar_event","description":"Takvime etkinlik ekleme ekranını açar. Tarihler ISO 8601 (yyyy-MM-ddTHH:mm).",
      "parameters":{"type":"OBJECT","properties":{
        "title":{"type":"STRING"},"start_iso":{"type":"STRING"},"end_iso":{"type":"STRING"},"location":{"type":"STRING"}},"required":["title","start_iso"]}},
     {"name":"add_reminder","description":"Belirli saate alarm/hatırlatıcı kurar. due_iso ISO 8601 (yyyy-MM-ddTHH:mm).",
      "parameters":{"type":"OBJECT","properties":{"title":{"type":"STRING"},"due_iso":{"type":"STRING"}},"required":["title","due_iso"]}},
     {"name":"send_whatsapp_message","description":"WhatsApp mesajı hazırlar. Kullanıcı mesajı WhatsApp'ta kendisi gönder tuşuyla yollar.",
      "parameters":{"type":"OBJECT","properties":{
        "recipient_name":{"type":"STRING"},"phone":{"type":"STRING"},"message":{"type":"STRING"}},"required":["message"]}},
     {"name":"save_whatsapp_contact","description":"Sık kullanılan kişiyi (ad + telefon, ülke koduyla) kaydeder.",
      "parameters":{"type":"OBJECT","properties":{"name":{"type":"STRING"},"phone":{"type":"STRING"}},"required":["name","phone"]}},
     {"name":"save_memory","description":"Kullanıcı hakkında kalıcı bilgiyi kaydeder. Üç alan da zorunlu.",
      "parameters":{"type":"OBJECT","properties":{
        "category":{"type":"STRING","description":"identity, preferences veya notes"},
        "key":{"type":"STRING"},"value":{"type":"STRING"}},"required":["category","key","value"]}},
     {"name":"delete_memory","description":"Kalıcı hafızadan kayıt siler.",
      "parameters":{"type":"OBJECT","properties":{
        "category":{"type":"STRING"},"key":{"type":"STRING"},"match_text":{"type":"STRING"}}}}
    ]
    """

    fun systemPrompt(prefs: Prefs): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy HH:mm", Locale("tr", "TR")).format(Date())
        return """
Sen JARVIS'sin — Android telefonda çalışan kişisel sesli AI asistanı.

KURALLAR:
- Türkçe konuş (kullanıcı başka dil kullanıyorsa o dilde yanıt ver).
- Kısa, net ve etkili ol; gereksiz tekrar yapma. Sesli konuştuğun için liste/markdown okuma.
- Araçları kullanarak görevleri tamamla, asla taklit etme veya hayal etme.
- Sistem hatalarını sesli ilet.
- Kullanıcı hakkında kalıcı bir bilgi öğrenirsen (ad, hitap, tercih, alışkanlık) save_memory'yi SESSİZCE çağır;
  category, key, value alanlarını doldur; her bilgi için ayrı çağrı yap.
- Kullanıcı bir kaydı artık istemiyorsa delete_memory kullan.
- Göreli zamanları ("yarın 14:00") aşağıdaki şu anki tarih/saate göre gerçek ISO tarihine çevir.
- WhatsApp'ta mesaj otomatik gönderilemez; mesajı hazırlayıp WhatsApp'ı açtığını, göndermek için kullanıcının
  gönder tuşuna basması gerektiğini söyle. Telefon numarası yoksa kayıtlı kişilerde ara; yoksa numarayı sor.
- Şu anki tarih/saat: $now
${prefs.memoryAsPromptText()}
""".trim()
    }

    private val http = OkHttpClient()

    fun run(ctx: Context, prefs: Prefs, name: String, a: JSONObject): String = when (name) {
        "open_app" -> openApp(ctx, a.optString("app_name"))
        "sys_info" -> sysInfo(ctx, a.optString("kind"))
        "get_weather" -> weather(a.optString("location"))
        "browser_control" -> browser(ctx, a)
        "play_media" -> playMedia(ctx, a.optString("query"), a.optString("provider", "auto"))
        "control_media" -> controlMedia(ctx, a.optString("action"))
        "add_calendar_event" -> addEvent(ctx, a)
        "add_reminder" -> addReminder(ctx, a)
        "send_whatsapp_message" -> whatsapp(ctx, prefs, a)
        "save_whatsapp_contact" -> {
            prefs.saveContact(a.optString("name"), a.optString("phone")); "Kişi kaydedildi."
        }
        "save_memory" -> {
            val c = a.optString("category"); val k = a.optString("key"); val v = a.optString("value")
            if (c.isBlank() || k.isBlank() || v.isBlank()) "Eksik alan, kaydedilmedi."
            else { prefs.saveMemory(c, k, v); "ok" }
        }
        "delete_memory" -> {
            val n = prefs.deleteMemory(
                a.optString("category").ifBlank { null },
                a.optString("key").ifBlank { null },
                a.optString("match_text").ifBlank { null })
            if (n > 0) "$n kayıt silindi." else "Eşleşen kayıt bulunamadı."
        }
        else -> "Bilinmeyen araç: $name"
    }

    private fun launch(ctx: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (_: Exception) { false }

    private fun openApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = appName.lowercase(Locale("tr"))
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale("tr")) == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale("tr")).contains(q) }
            ?: return "'$appName' adlı uygulama bulunamadı."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Uygulama açılamadı."
        return if (launch(ctx, i)) "${hit.loadLabel(pm)} açıldı." else "Uygulama açılamadı."
    }

    private fun sysInfo(ctx: Context, kind: String): String {
        return when (kind.lowercase()) {
            "battery", "pil" -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val charging = bm.isCharging
                "Pil %$lvl, ${if (charging) "şarj oluyor" else "şarjda değil"}."
            }
            else -> SimpleDateFormat("d MMMM yyyy EEEE, HH:mm", Locale("tr", "TR")).format(Date())
        }
    }

    private fun weather(location: String): String {
        val loc = URLEncoder.encode(location, "UTF-8")
        val req = Request.Builder()
            .url("https://wttr.in/$loc?format=%l:+%C,+%t,+nem+%h,+rüzgar+%w&lang=tr")
            .header("User-Agent", "JARVIS-Android").build()
        return try {
            http.newCall(req).execute().use { it.body?.string()?.trim().orEmpty().ifBlank { "Veri alınamadı." } }
        } catch (e: Exception) { "Hava durumu alınamadı: ${e.message}" }
    }

    private fun browser(ctx: Context, a: JSONObject): String {
        val q = a.optString("query")
        return when (a.optString("action")) {
            "open_url" -> {
                var u = a.optString("url").ifBlank { q }
                if (!u.startsWith("http")) u = "https://$u"
                if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) "Açıldı: $u" else "Açılamadı."
            }
            "play_youtube" -> playMedia(ctx, q, "youtube")
            else -> {
                val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
                if (launch(ctx, i)) "Aranıyor: $q"
                else if (launch(ctx, Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")))))
                    "Aranıyor: $q" else "Arama açılamadı."
            }
        }
    }

    private fun playMedia(ctx: Context, q: String, provider: String): String {
        val enc = URLEncoder.encode(q, "UTF-8")
        if (provider == "spotify" || provider == "auto") {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:$enc"))
            if (launch(ctx, i)) return "Spotify'da aranıyor: $q (çalmak için parçaya dokunmak gerekebilir)."
            if (provider == "spotify") return "Spotify yüklü değil."
        }
        val yt = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube")
            .putExtra("query", q)
        if (launch(ctx, yt)) return "YouTube'da açılıyor: $q"
        return if (launch(ctx, Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=$enc"))))
            "YouTube araması açıldı: $q" else "Açılamadı."
    }

    private fun controlMedia(ctx: Context, action: String): String {
        val code = when (action.lowercase()) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "resume", "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return "Bilinmeyen komut: $action"
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Tamam: $action"
    }

    private fun parseMillis(iso: String): Long =
        LocalDateTime.parse(iso.take(16), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"))
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private fun addEvent(ctx: Context, a: JSONObject): String {
        val start = try { parseMillis(a.optString("start_iso")) } catch (_: Exception) {
            return "Tarih biçimi anlaşılamadı."
        }
        val end = a.optString("end_iso").takeIf { it.isNotBlank() }
            ?.let { try { parseMillis(it) } catch (_: Exception) { null } } ?: (start + 3_600_000)
        val i = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, a.optString("title"))
            .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("location"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
        return if (launch(ctx, i)) "Takvim ekranı açıldı; kullanıcının Kaydet'e basması gerekiyor."
        else "Takvim uygulaması bulunamadı."
    }

    private fun addReminder(ctx: Context, a: JSONObject): String {
        val t = try {
            LocalDateTime.parse(a.optString("due_iso").take(16),
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"))
        } catch (_: Exception) { return "Tarih biçimi anlaşılamadı." }
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, t.hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, t.minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("title"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) "Alarm kuruldu: ${t.toLocalTime()} — ${a.optString("title")}"
        else "Saat uygulaması bulunamadı."
    }

    private fun whatsapp(ctx: Context, prefs: Prefs, a: JSONObject): String {
        val msg = a.optString("message")
        var phone = a.optString("phone").filter { it.isDigit() }
        if (phone.isBlank()) {
            val name = a.optString("recipient_name")
            phone = prefs.findContact(name)?.filter { it.isDigit() }.orEmpty()
            if (phone.isBlank()) return "'$name' için numara kayıtlı değil. Kullanıcıdan numarayı iste."
        }
        val u = Uri.parse("https://wa.me/$phone?text=" + URLEncoder.encode(msg, "UTF-8"))
        return if (launch(ctx, Intent(Intent.ACTION_VIEW, u)))
            "WhatsApp açıldı, mesaj hazır. Göndermek için kullanıcı gönder tuşuna basmalı."
        else "WhatsApp açılamadı."
    }
}
