package com.jarvis.android

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF05080F)
private val Cyan = Color(0xFF29D3FF)
private val Panel = Color(0xFF0E1622)

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                JarvisScreen(vm)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Arka planda mikrofon erişimi Android tarafından kesilir; oturumu temiz kapat.
        vm.stop()
    }
}

@Composable
fun JarvisScreen(vm: MainViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var showSettings by remember { mutableStateOf(vm.apiKey.value.isBlank()) }
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.start() else { vm.error.value = "Mikrofon izni gerekli."; vm.state.value = JState.ERROR }
    }
    fun toggle() {
        if (vm.state.value == JState.IDLE || vm.state.value == JState.ERROR) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) vm.start()
            else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else vm.stop()
    }

    LaunchedEffect(vm.lines.size, vm.lines.lastOrNull()?.text) {
        if (vm.lines.isNotEmpty()) listState.animateScrollToItem(vm.lines.lastIndex)
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("J.A.R.V.I.S", color = Cyan, fontSize = 20.sp, letterSpacing = 4.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showSettings = true }) {
                Icon(Icons.Filled.Settings, contentDescription = "Ayarlar", tint = Color.Gray)
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.lines) { l ->
                Box(Modifier.fillMaxWidth(), contentAlignment =
                    if (l.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(l.text, color = Color.White,
                        modifier = Modifier.widthIn(max = 300.dp)
                            .background(if (l.fromUser) Color(0xFF16324A) else Panel, RoundedCornerShape(14.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp))
                }
            }
        }

        val label = when (vm.state.value) {
            JState.IDLE -> "Dokun ve konuş"
            JState.CONNECTING -> "Bağlanıyor…"
            JState.LISTENING -> "Dinliyorum"
            JState.SPEAKING -> "Konuşuyor"
            JState.ERROR -> "Hata"
        }
        Text(label, color = Color.Gray, fontSize = 13.sp)
        if (vm.error.value.isNotBlank())
            Text(vm.error.value, color = Color(0xFFFF6B6B), fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))

        Orb(vm.state.value) { toggle() }
        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Yaz…") }, singleLine = true, shape = RoundedCornerShape(24.dp)
            )
            IconButton(onClick = { vm.sendText(text); text = "" },
                enabled = vm.state.value == JState.LISTENING || vm.state.value == JState.SPEAKING) {
                Icon(Icons.Filled.Send, contentDescription = "Gönder", tint = Cyan)
            }
        }
    }

    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun Orb(state: JState, onClick: () -> Unit) {
    val active = state == JState.LISTENING || state == JState.SPEAKING || state == JState.CONNECTING
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        1f, if (state == JState.SPEAKING) 1.18f else 1.08f,
        infiniteRepeatable(tween(if (state == JState.SPEAKING) 450 else 1100), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        Modifier.size(110.dp).scale(if (active) pulse else 1f)
            .border(2.dp, if (state == JState.ERROR) Color(0xFFFF6B6B) else Cyan, CircleShape)
            .background(Cyan.copy(alpha = if (active) 0.22f else 0.08f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(if (active) Icons.Filled.Stop else Icons.Filled.Mic, contentDescription = null,
            tint = Cyan, modifier = Modifier.size(42.dp))
    }
}

@Composable
fun SettingsDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var key by remember { mutableStateOf(vm.prefs.apiKey) }
    var voice by remember { mutableStateOf(vm.prefs.voice) }
    var model by remember { mutableStateOf(vm.prefs.model) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                vm.saveKey(key); vm.prefs.voice = voice; vm.prefs.model = model; onDismiss()
            }) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Kapat") } },
        title = { Text("Ayarlar") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ücretsiz Gemini API anahtarını aistudio.google.com/apikey adresinden alabilirsin.",
                    fontSize = 12.sp, color = Color.Gray)
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API anahtarı") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(voice, { voice = it }, label = { Text("Ses (Charon, Puck, Kore…)") },
                    singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true)
            }
        }
    )
}
