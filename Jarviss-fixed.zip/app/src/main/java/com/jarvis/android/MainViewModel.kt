package com.jarvis.android

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel

enum class JState { IDLE, CONNECTING, LISTENING, SPEAKING, ERROR }

data class ChatLine(val fromUser: Boolean, var text: String)

class MainViewModel(app: Application) : AndroidViewModel(app), GeminiLiveClient.Listener {
    val prefs = Prefs(app)

    val state = mutableStateOf(JState.IDLE)
    val error = mutableStateOf("")
    val lines = mutableStateListOf<ChatLine>()
    val apiKey = mutableStateOf(prefs.apiKey)

    private var client: GeminiLiveClient? = null
    private var mic: MicRecorder? = null
    private val speaker = SpeakerPlayer()
    @Volatile private var speaking = false

    fun saveKey(k: String) { prefs.apiKey = k; apiKey.value = k.trim() }

    fun start() {
        if (state.value == JState.CONNECTING || state.value == JState.LISTENING ||
            state.value == JState.SPEAKING) return
        if (prefs.apiKey.isBlank()) { error.value = "Önce Gemini API anahtarını gir."; state.value = JState.ERROR; return }
        error.value = ""
        state.value = JState.CONNECTING
        val ctx = getApplication<Application>()
        client = GeminiLiveClient(
            apiKey = prefs.apiKey,
            model = prefs.model,
            voice = prefs.voice,
            systemPrompt = Tools.systemPrompt(prefs),
            listener = this,
            toolCall = { n, a -> Tools.run(ctx, prefs, n, a) },
        ).also { it.connect() }
    }

    fun stop() {
        mic?.stop(); mic = null
        speaker.stop()
        client?.close(); client = null
        speaking = false
        if (state.value != JState.ERROR) state.value = JState.IDLE
    }

    fun sendText(t: String) {
        if (t.isBlank()) return
        lines.add(ChatLine(true, t))
        client?.sendText(t)
    }

    // ---- Listener (arka plan thread'lerinden çağrılır) ----
    override fun onReady() {
        speaker.start()
        mic = MicRecorder { chunk ->
            // Model konuşurken mikrofonu göndermeye devam et: sözü kesme (barge-in) çalışsın.
            client?.sendAudio(chunk)
        }.also { it.start() }
        state.value = JState.LISTENING
    }

    override fun onAudio(pcm: ByteArray) {
        speaking = true
        state.value = JState.SPEAKING
        speaker.write(pcm)
    }

    override fun onInterrupted() { speaker.flush(); speaking = false; state.value = JState.LISTENING }

    override fun onUserText(text: String) {
        val last = lines.lastOrNull()
        if (last != null && last.fromUser) lines[lines.lastIndex] = last.copy(text = last.text + text)
        else lines.add(ChatLine(true, text.trimStart()))
    }

    override fun onModelText(text: String) {
        val last = lines.lastOrNull()
        if (last != null && !last.fromUser) lines[lines.lastIndex] = last.copy(text = last.text + text)
        else lines.add(ChatLine(false, text.trimStart()))
    }

    override fun onTurnComplete() { speaking = false; if (client != null) state.value = JState.LISTENING }

    override fun onClosed(reason: String) {
        if (client == null) return // kullanıcı kendisi durdurdu
        mic?.stop(); mic = null
        speaker.stop()
        client = null
        error.value = reason
        state.value = if (reason.contains("API") || reason.contains("Bağlantı hatası") ||
            reason.contains("Unable")) JState.ERROR else JState.IDLE
    }

    override fun onCleared() { stop() }
}
